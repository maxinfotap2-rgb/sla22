package com.stalkers;

import com.stalkers.entity.Behavior;
import com.stalkers.entity.Breakables;
import com.stalkers.entity.StalkerEntity;
import com.stalkers.entity.StalkerType;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Faz os stalkers aparecerem perto do jogador.
 * Ajuste os numeros abaixo para deixar mais ou menos frequente.
 */
public final class StalkerSpawner {
    /** A noite: em media 1 tentativa de spawn a cada X segundos. */
    public static final int NIGHT_CHANCE = 45;
    /** De dia, no escuro (cavernas): em media 1 a cada X segundos. */
    public static final int DARK_CHANCE = 150;
    /** Maximo de stalkers ao mesmo tempo perto de um jogador. */
    public static final int MAX_NEAR = 2;
    /** Espera minima entre dois spawns para o mesmo jogador (segundos). */
    public static final int COOLDOWN_SECONDS = 40;

    private static final Map<UUID, Long> NEXT_ALLOWED = new HashMap<>();

    private StalkerSpawner() {
    }

    public static void tick(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) return;
        if (world.getTime() % 20 != 0) return;
        if (world.getDifficulty() == Difficulty.PEACEFUL) return;

        for (ServerPlayerEntity p : world.getPlayers()) {
            if (p.isSpectator() || p.isCreative()) continue;
            long now = world.getTime();
            Long next = NEXT_ALLOWED.get(p.getUuid());
            if (next != null && now < next) continue;

            int near = world.getEntitiesByClass(StalkerEntity.class, p.getBoundingBox().expand(96), e -> true).size();
            if (near >= MAX_NEAR) continue;

            boolean night = world.isNight();
            boolean dark = world.getLightLevel(p.getBlockPos()) < 6;
            int chance = night ? NIGHT_CHANCE : (dark ? DARK_CHANCE : 0);
            if (chance <= 0 || world.random.nextInt(chance) != 0) continue;

            if (trySpawn(world, p, night)) {
                NEXT_ALLOWED.put(p.getUuid(), now + COOLDOWN_SECONDS * 20L);
            }
        }
    }

    /** Usado tambem pelo comando /stalkers spawn. */
    public static boolean trySpawn(ServerWorld world, ServerPlayerEntity p, boolean night) {
        Random r = world.random;

        if (night && r.nextInt(100) < 40 && spawnAtWindow(world, p)) return true;
        if (night && r.nextInt(100) < 30 && spawnAtDoor(world, p)) return true;

        StalkerType type = StalkerType.random(r, Behavior.values());
        return spawnHidden(world, p, type);
    }

    // ------------------------------------------------------------- janela

    public static boolean spawnAtWindow(ServerWorld world, ServerPlayerEntity p) {
        BlockPos center = p.getBlockPos();
        List<BlockPos[]> found = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -10; dx <= 10; dx++) {
            for (int dz = -10; dz <= 10; dz++) {
                for (int dy = -2; dy <= 4; dy++) {
                    m.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockState s = world.getBlockState(m);
                    if (!Breakables.isGlass(world, m, s)) continue;
                    BlockPos glass = m.toImmutable();
                    BlockPos feet = outsideSpot(world, p, glass);
                    if (feet != null) found.add(new BlockPos[]{glass, feet});
                }
            }
        }
        if (found.isEmpty()) return false;
        BlockPos[] pick = found.get(world.random.nextInt(found.size()));
        StalkerType type = StalkerType.random(world.random, Behavior.WINDOW);
        StalkerEntity e = create(world, type, pick[1], pick[0]);
        if (e == null) return false;
        e.setupWindow(pick[0]);
        world.spawnEntity(e);
        return true;
    }

    /** Lugar do lado de FORA do vidro (mais longe do jogador), com chao. */
    private static BlockPos outsideSpot(ServerWorld world, ServerPlayerEntity p, BlockPos glass) {
        double glassDist = p.squaredDistanceTo(Vec3d.ofCenter(glass));
        for (Direction d : Direction.Type.HORIZONTAL) {
            BlockPos n = glass.offset(d);
            if (p.squaredDistanceTo(Vec3d.ofCenter(n)) <= glassDist + 0.5) continue;
            if (!world.getBlockState(n).isAir()) continue;
            if (!world.getBlockState(glass.offset(d.getOpposite())).isAir()) continue; // tem que ter ar do lado de dentro tambem
            for (int down = 0; down <= 3; down++) {
                BlockPos f = n.down(down);
                if (standable(world, f)) return f;
            }
        }
        return null;
    }

    // --------------------------------------------------------------- porta

    public static boolean spawnAtDoor(ServerWorld world, ServerPlayerEntity p) {
        BlockPos center = p.getBlockPos();
        List<BlockPos[]> found = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -16; dx <= 16; dx++) {
            for (int dz = -16; dz <= 16; dz++) {
                for (int dy = -3; dy <= 3; dy++) {
                    m.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockState s = world.getBlockState(m);
                    if (!(s.getBlock() instanceof DoorBlock)) continue;
                    if (s.get(DoorBlock.HALF) != DoubleBlockHalf.LOWER) continue;
                    BlockPos door = m.toImmutable();
                    Direction facing = s.get(DoorBlock.FACING);
                    BlockPos a = door.offset(facing);
                    BlockPos b = door.offset(facing.getOpposite());
                    BlockPos outside = p.squaredDistanceTo(Vec3d.ofCenter(a)) > p.squaredDistanceTo(Vec3d.ofCenter(b)) ? a : b;
                    if (standable(world, outside)) found.add(new BlockPos[]{door, outside});
                }
            }
        }
        if (found.isEmpty()) return false;
        BlockPos[] pick = found.get(world.random.nextInt(found.size()));
        StalkerType type = StalkerType.random(world.random, Behavior.DOOR);
        StalkerEntity e = create(world, type, pick[1], pick[0]);
        if (e == null) return false;
        e.setupDoor(pick[0]);
        world.spawnEntity(e);
        return true;
    }

    // -------------------------------------------------------------- escondido

    public static boolean spawnHidden(ServerWorld world, ServerPlayerEntity p, StalkerType type) {
        Random r = world.random;
        Vec3d look = p.getRotationVec(1.0f);
        double minD = 20, maxD = 36;
        if (type.behavior == Behavior.WATCHER) {
            minD = 26;
            maxD = 42;
        } else if (type.behavior == Behavior.EYES) {
            minD = 9;
            maxD = 16;
        }
        for (int attempt = 0; attempt < 40; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double dist = minD + r.nextDouble() * (maxD - minD);
            double x = p.getX() + Math.cos(ang) * dist;
            double z = p.getZ() + Math.sin(ang) * dist;

            // fora da visao (atras ou do lado) - exceto WATCHER, que pode estar a vista, la longe
            Vec3d dir = new Vec3d(x - p.getX(), 0, z - p.getZ()).normalize();
            double dot = dir.x * look.x + dir.z * look.z;
            if (type.behavior != Behavior.WATCHER && dot > 0.2) continue;

            int bx = MathHelper.floor(x), bz = MathHelper.floor(z);
            for (int dy = 8; dy >= -8; dy--) {
                BlockPos f = new BlockPos(bx, p.getBlockY() + dy, bz);
                if (!standable(world, f)) continue;
                if (world.getLightLevel(LightType.BLOCK, f) > 9) continue;
                if (type.behavior == Behavior.EYES && world.getLightLevel(f) > 4) continue;
                BlockPos at = type.behavior == Behavior.EYES ? f.up() : f;
                StalkerEntity e = create(world, type, at, p.getBlockPos());
                if (e == null) continue;
                if (type.behavior == Behavior.EYES) {
                    e.refreshPositionAndAngles(f.getX() + 0.5, f.getY() + 1.4, f.getZ() + 0.5, e.getYaw(), 0);
                }
                world.spawnEntity(e);
                return true;
            }
        }
        return false;
    }

    // -------------------------------------------------------------- util

    private static boolean standable(ServerWorld world, BlockPos feet) {
        BlockState below = world.getBlockState(feet.down());
        return below.isSideSolidFullSquare(world, feet.down(), Direction.UP)
                && world.getBlockState(feet).isAir()
                && world.getBlockState(feet.up()).isAir()
                && world.getFluidState(feet).isEmpty();
    }

    private static StalkerEntity create(ServerWorld world, StalkerType type, BlockPos feet, BlockPos lookAt) {
        StalkerEntity e = type.entityType().create(world);
        if (e == null) return null;
        double x = feet.getX() + 0.5, y = feet.getY(), z = feet.getZ() + 0.5;
        float yaw = (float) (MathHelper.atan2(lookAt.getZ() + 0.5 - z, lookAt.getX() + 0.5 - x) * (180.0 / Math.PI)) - 90f;
        e.refreshPositionAndAngles(x, y, z, yaw, 0f);
        e.setHeadYaw(yaw);
        if (!world.isSpaceEmpty(e, e.getBoundingBox())) return null;
        return e;
    }
}
