package com.stalkers;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.stalkers.entity.StalkerEntity;
import com.stalkers.entity.StalkerType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class StalkersMod implements ModInitializer {
    public static final String MODID = "stalkers";
    private static final List<Item> EGGS = new ArrayList<>();

    @Override
    public void onInitialize() {
        for (StalkerType k : StalkerType.values()) {
            EntityDimensions dims = k.behavior == com.stalkers.entity.Behavior.EYES
                    ? EntityDimensions.fixed(0.4f, 0.4f)
                    : EntityDimensions.fixed(0.6f, 1.9f);
            EntityType<StalkerEntity> type = Registry.register(Registries.ENTITY_TYPE, new Identifier(MODID, k.id),
                    FabricEntityTypeBuilder.<StalkerEntity>create(SpawnGroup.MONSTER, StalkerEntity::new)
                            .dimensions(dims)
                            .trackRangeBlocks(160)
                            .trackedUpdateRate(2)
                            .build());
            k.bind(type);
            FabricDefaultAttributeRegistry.register(type, StalkerEntity.createAttributes());

            Item egg = Registry.register(Registries.ITEM, new Identifier(MODID, k.id + "_spawn_egg"),
                    new SpawnEggItem(type, 0x0B0B0B, 0x7A0000, new Item.Settings()));
            EGGS.add(egg);
        }

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            for (Item egg : EGGS) entries.add(egg);
        });

        ServerTickEvents.END_WORLD_TICK.register(StalkerSpawner::tick);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            LiteralArgumentBuilder<ServerCommandSource> root = CommandManager.literal("stalkers")
                    .requires(src -> src.hasPermissionLevel(2));

            root.then(CommandManager.literal("janela").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                boolean ok = StalkerSpawner.spawnAtWindow(p.getServerWorld(), p);
                ctx.getSource().sendFeedback(() -> Text.literal(ok
                        ? "Tem alguem na janela..."
                        : "Nenhuma janela (vidro) perto de voce, a ate 10 blocos."), false);
                return ok ? 1 : 0;
            }));

            root.then(CommandManager.literal("porta").executes(ctx -> {
                ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                boolean ok = StalkerSpawner.spawnAtDoor(p.getServerWorld(), p);
                ctx.getSource().sendFeedback(() -> Text.literal(ok
                        ? "Tem alguem na porta..."
                        : "Nenhuma porta perto de voce, a ate 16 blocos."), false);
                return ok ? 1 : 0;
            }));

            LiteralArgumentBuilder<ServerCommandSource> spawn = CommandManager.literal("spawn");
            for (StalkerType k : StalkerType.values()) {
                spawn.then(CommandManager.literal(k.id).executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    boolean ok = StalkerSpawner.spawnHidden(p.getServerWorld(), p, k);
                    ctx.getSource().sendFeedback(() -> Text.literal(ok
                            ? "Ele esta por perto..."
                            : "Nao achei lugar escondido para ele. Tente em outro lugar."), false);
                    return ok ? 1 : 0;
                }));
            }
            root.then(spawn);
            dispatcher.register(root);
        });
    }
}
