package com.stalkers.entity;

/**
 * CHASER  - segue de longe; se voce olhar pra ele, ele CORRE atras de voce.
 * STALKER - chega mais perto quando voce nao esta olhando; congela quando voce olha.
 * WATCHER - fica parado longe, so observando; some se voce chegar perto.
 * WINDOW  - aparece do lado de fora de uma janela, encara, quebra o vidro e entra.
 * DOOR    - aparece do lado de fora de uma porta, bate, arromba e entra.
 * EYES    - so os olhos no escuro.
 */
public enum Behavior {
    CHASER,
    STALKER,
    WATCHER,
    WINDOW,
    DOOR,
    EYES
}
