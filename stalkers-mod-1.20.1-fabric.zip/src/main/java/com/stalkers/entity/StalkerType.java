package com.stalkers.entity;

import com.stalkers.StalkersMod;
import net.minecraft.entity.EntityType;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum StalkerType {
    RUN("run", Behavior.CHASER, 3.0f, 1.9f, 0.322f, false),
    GRIP("grip", Behavior.CHASER, 3.2f, 1.6f, 0.3821f, false),
    GOAT("goat", Behavior.CHASER, 3.4f, 1.5f, 0.6951f, false),
    GOATEVIL("goatevil", Behavior.CHASER, 3.6f, 1.5f, 0.5985f, false),
    JESTER("jester", Behavior.WINDOW, 2.8f, 1.5f, 0.4091f, false),
    TORTURA("tortura", Behavior.WINDOW, 2.8f, 1.5f, 0.3807f, false),
    WATCHER("watcher", Behavior.WATCHER, 3.6f, 1.5f, 0.2405f, false),
    VIGILANTE("vigilante", Behavior.WATCHER, 2.6f, 1.5f, 0.4796f, false),
    EVIL("evil", Behavior.CHASER, 3.0f, 1.6f, 0.5205f, false),
    ANSIEDAD("ansiedad", Behavior.DOOR, 3.2f, 1.5f, 0.3761f, false),
    REDLIGHT("redlight", Behavior.CHASER, 3.0f, 1.7f, 0.4943f, false),
    SMILER("smiler", Behavior.WINDOW, 2.0f, 1.5f, 0.6057f, false),
    OBSERVER("observer", Behavior.WATCHER, 3.0f, 1.5f, 0.8264f, false),
    PUERTAS("puertas", Behavior.DOOR, 1.3f, 1.5f, 3.8261f, false),
    PEEKER("peeker", Behavior.DOOR, 2.4f, 1.5f, 0.5619f, false),
    WINDOW("window", Behavior.WINDOW, 2.4f, 1.5f, 0.4481f, false),
    SCREAMER("screamer", Behavior.CHASER, 2.8f, 1.8f, 0.2102f, false),
    VIDA("vida", Behavior.STALKER, 3.0f, 1.5f, 0.3466f, false),
    WINDOWBREAK("windowbreak", Behavior.WINDOW, 1.8f, 1.5f, 0.4676f, false),
    SPOTTED("spotted", Behavior.CHASER, 3.0f, 1.7f, 1.2785f, false),
    ESCALERA("escalera", Behavior.STALKER, 2.6f, 1.5f, 0.7708f, false),
    LIFE("life", Behavior.WATCHER, 3.0f, 1.5f, 1.0539f, false),
    HEY("hey", Behavior.STALKER, 3.0f, 1.5f, 0.8092f, false),
    BIPEDAL("bipedal", Behavior.STALKER, 3.4f, 1.5f, 0.3762f, false),
    WOMAN("woman", Behavior.STALKER, 2.6f, 1.5f, 0.8361f, false),
    GOAT_WINDOW("goat_window", Behavior.WINDOW, 2.8f, 1.5f, 0.5516f, false),
    SUFRIMIENTO("sufrimiento", Behavior.WATCHER, 3.6f, 1.5f, 0.5133f, false),
    PEEK1("peek1", Behavior.WINDOW, 2.4f, 1.5f, 0.5115f, false),
    PEEK2("peek2", Behavior.WINDOW, 2.4f, 1.5f, 0.5086f, false),
    LUZ("luz", Behavior.WATCHER, 2.6f, 1.5f, 0.4292f, true),
    ENVUELTO("envuelto", Behavior.STALKER, 2.8f, 1.5f, 0.2771f, false),
    QUAD("quad", Behavior.CHASER, 1.6f, 2.0f, 1.1261f, false),
    EYES("eyes", Behavior.EYES, 0.35f, 1.5f, 1.65f, true);

    public final String id;
    public final Behavior behavior;
    public final float height;
    public final float chaseSpeed;
    public final float aspect;
    public final boolean fullbright;
    public final Identifier texture;
    public final Identifier angryTexture;
    private EntityType<StalkerEntity> entityType;

    private static final Map<EntityType<?>, StalkerType> BY_TYPE = new HashMap<>();

    StalkerType(String id, Behavior behavior, float height, float chaseSpeed, float aspect, boolean fullbright) {
        this.id = id;
        this.behavior = behavior;
        this.height = height;
        this.chaseSpeed = chaseSpeed;
        this.aspect = aspect;
        this.fullbright = fullbright;
        this.texture = new Identifier(StalkersMod.MODID, "textures/entity/" + id + ".png");
        this.angryTexture = new Identifier(StalkersMod.MODID, "textures/entity/" + id + "_angry.png");
    }

    public void bind(EntityType<StalkerEntity> type) {
        this.entityType = type;
        BY_TYPE.put(type, this);
    }

    public EntityType<StalkerEntity> entityType() {
        return entityType;
    }

    public static StalkerType of(EntityType<?> type) {
        StalkerType t = BY_TYPE.get(type);
        return t != null ? t : RUN;
    }

    public static StalkerType random(Random random, Behavior... allowed) {
        List<StalkerType> list = new ArrayList<>();
        for (StalkerType t : values()) {
            for (Behavior b : allowed) {
                if (t.behavior == b) {
                    list.add(t);
                    break;
                }
            }
        }
        if (list.isEmpty()) return RUN;
        return list.get(random.nextInt(list.size()));
    }
}
