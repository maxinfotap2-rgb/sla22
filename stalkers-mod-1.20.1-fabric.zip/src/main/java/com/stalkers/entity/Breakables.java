package com.stalkers.entity;

import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

public final class Breakables {
    private Breakables() {
    }

    /** Vidro, vidro colorido, painel de vidro (janela) etc. */
    public static boolean isGlass(BlockView world, BlockPos pos, BlockState state) {
        if (state.isAir() || state.hasBlockEntity()) return false;
        if (state.getHardness(world, pos) < 0) return false;
        return state.getSoundGroup() == BlockSoundGroup.GLASS;
    }

    /** Porta, alcapao, portao de cerca. */
    public static boolean isDoor(BlockState state) {
        return state.getBlock() instanceof DoorBlock
                || state.getBlock() instanceof TrapdoorBlock
                || state.getBlock() instanceof FenceGateBlock;
    }

    public static boolean isBreakable(BlockView world, BlockPos pos, BlockState state) {
        return isGlass(world, pos, state) || isDoor(state);
    }
}
