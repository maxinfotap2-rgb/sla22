package com.stalkers.entity;

import com.stalkers.Net;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.pathing.MobNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.WorldEvents;

public class StalkerEntity extends HostileEntity {
    public static final int S_STALK = 0;
    public static final int S_CHASE = 1;
    public static final int S_WINDOW = 2;
    public static final int S_DOOR = 3;

    private static final TrackedData<Integer> STATE =
            DataTracker.registerData(StalkerEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> TARGET_ID =
            DataTracker.registerData(StalkerEntity.class, TrackedDataHandlerRegistry.INTEGER);

    /** Tempo maximo que um stalker fica no mundo (3 minutos). */
    private static final int MAX_LIFE = 20 * 180;
    /** Duracao maxima de uma perseguicao (30 segundos). */
    private static final int MAX_CHASE = 20 * 30;

    public final StalkerType kind;

    private int life;
    private int watchedTicks;
    private int stalkTicks;
    private int chaseTicks;
    private int waitTicks = 100;
    private int attackCooldown;
    private int breakProgress;
    private int noTargetTicks;
    private boolean announced;
    private boolean scared;
    private BlockPos objective;
    private BlockPos breaking;

    public StalkerEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.kind = StalkerType.of(type);
        this.experiencePoints = 10;
        if (this.getNavigation() instanceof MobNavigation nav) {
            nav.setCanPathThroughDoors(true);
        }
        if (this.kind.behavior == Behavior.EYES) {
            this.setNoGravity(true);
        }
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 60.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 7.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 96.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.8);
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(STATE, S_STALK);
        this.dataTracker.startTracking(TARGET_ID, -1);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
    }

    // ---------------------------------------------------------------- estado

    public int getStalkerState() {
        return this.dataTracker.get(STATE);
    }

    private void setStalkerState(int s) {
        this.dataTracker.set(STATE, s);
    }

    public int getTargetId() {
        return this.dataTracker.get(TARGET_ID);
    }

    public boolean isAngryVisual() {
        return getStalkerState() == S_CHASE;
    }

    /** Chamado pelo spawner: fica do lado de fora da janela. */
    public void setupWindow(BlockPos glass) {
        this.objective = glass;
        this.waitTicks = 80 + this.random.nextInt(140);
        setStalkerState(S_WINDOW);
    }

    /** Chamado pelo spawner: fica do lado de fora da porta. */
    public void setupDoor(BlockPos door) {
        this.objective = door;
        this.waitTicks = 40 + this.random.nextInt(60);
        setStalkerState(S_DOOR);
    }

    // ---------------------------------------------------------------- IA

    @Override
    protected void mobTick() {
        super.mobTick();
        if (!(this.getWorld() instanceof ServerWorld world)) return;

        life++;
        if (attackCooldown > 0) attackCooldown--;

        if (!announced) {
            announced = true;
            Net.appear(world, this);
        }
        if (life > MAX_LIFE) {
            vanish();
            return;
        }

        PlayerEntity target = world.getClosestPlayer(getX(), getY(), getZ(), 80.0,
                EntityPredicates.EXCEPT_CREATIVE_OR_SPECTATOR);
        if (target == null || !target.isAlive()) {
            this.dataTracker.set(TARGET_ID, -1);
            if (++noTargetTicks > 200) vanish();
            return;
        }
        noTargetTicks = 0;
        this.dataTracker.set(TARGET_ID, target.getId());

        switch (getStalkerState()) {
            case S_CHASE -> tickChase(world, target);
            case S_WINDOW -> tickWindow(world, target);
            case S_DOOR -> tickDoor(world, target);
            default -> tickStalk(world, target);
        }
    }

    private void tickStalk(ServerWorld world, PlayerEntity p) {
        stalkTicks++;
        double dist = Math.sqrt(this.squaredDistanceTo(p));
        boolean watched = isWatchedBy(p);
        this.getLookControl().lookAt(p, 30f, 30f);

        switch (kind.behavior) {
            case CHASER -> {
                if (watched) watchedTicks++;
                if (watchedTicks >= 8 || scared || stalkTicks > 20 * 40) {
                    startChase();
                    return;
                }
                if (dist > 18) moveTo(p, 1.0);
                else if (dist < 10) this.getNavigation().stop();
            }
            case WATCHER -> {
                if (watched) watchedTicks++;
                if (dist < 14 || watchedTicks > 80 || scared) {
                    vanish();
                    return;
                }
                if (dist > 40) moveTo(p, 0.8);
                else this.getNavigation().stop();
            }
            case EYES -> {
                if (watched) watchedTicks++;
                if (dist < 6 || watchedTicks > 30 || scared) {
                    vanish();
                    return;
                }
                this.getNavigation().stop();
            }
            default -> { // STALKER (e WINDOW/DOOR que nasceram longe de janela/porta)
                if (scared) {
                    vanish();
                    return;
                }
                if (watched) {
                    // congela quando voce olha
                    watchedTicks++;
                    this.getNavigation().stop();
                    if (watchedTicks > 60) vanish();
                    return;
                }
                if (dist < 2.6) {
                    attack(world, p, true);
                    vanish();
                    return;
                }
                moveTo(p, 0.9);
                breakThrough(world, p, 50);
            }
        }
    }

    private void tickWindow(ServerWorld world, PlayerEntity p) {
        this.getNavigation().stop();
        this.getLookControl().lookAt(p, 30f, 30f);
        if (objective == null || !Breakables.isGlass(world, objective, world.getBlockState(objective))) {
            startChase();
            return;
        }
        if (breaking == null) {
            waitTicks -= isWatchedBy(p) ? 3 : 1;
            if (waitTicks <= 0) {
                breaking = objective;
                breakProgress = 0;
            }
            return;
        }
        if (tickBreak(world, breaking, 24)) {
            // quebra o resto da janela (vidro em cima e embaixo)
            if (griefing(world)) {
                for (BlockPos q : new BlockPos[]{objective.up(), objective.down(), objective.up(2)}) {
                    if (Breakables.isGlass(world, q, world.getBlockState(q))) world.breakBlock(q, false);
                }
            }
            Net.crack(world, objective);
            startChase();
        }
    }

    private void tickDoor(ServerWorld world, PlayerEntity p) {
        if (objective == null || !Breakables.isDoor(world.getBlockState(objective))) {
            startChase();
            return;
        }
        double d = Math.sqrt(this.squaredDistanceTo(Vec3d.ofCenter(objective)));
        if (d > 2.2) {
            this.getNavigation().startMovingTo(objective.getX() + 0.5, objective.getY(), objective.getZ() + 0.5, 1.0);
            return;
        }
        this.getNavigation().stop();
        if (waitTicks > 0) {
            waitTicks--;
            return;
        }
        if (breaking == null) {
            breaking = objective;
            breakProgress = 0;
        }
        if (tickBreak(world, breaking, 120)) {
            startChase();
        }
    }

    private void tickChase(ServerWorld world, PlayerEntity p) {
        chaseTicks++;
        double dist = Math.sqrt(this.squaredDistanceTo(p));
        if (chaseTicks > MAX_CHASE || dist > 56) {
            vanish();
            return;
        }
        this.getLookControl().lookAt(p, 30f, 30f);

        if (breaking != null) {
            this.getNavigation().stop();
            boolean door = Breakables.isDoor(world.getBlockState(breaking));
            tickBreak(world, breaking, door ? 50 : 12);
            return;
        }

        if (dist < 2.4 + this.getWidth()) {
            attack(world, p, false);
        }
        moveTo(p, kind.chaseSpeed);
        breakThrough(world, p, 0);
    }

    private void startChase() {
        if (getStalkerState() == S_CHASE) return;
        setStalkerState(S_CHASE);
        chaseTicks = 0;
        breaking = null;
        this.playSound(SoundEvents.ENTITY_ENDERMAN_SCREAM, 2.0f, 0.55f);
    }

    // ------------------------------------------------------------ movimento

    private void moveTo(PlayerEntity p, double speed) {
        if (this.age % 10 == 0 || this.getNavigation().isIdle()) {
            boolean ok = this.getNavigation().startMovingTo(p, speed);
            if (!ok) {
                // sem caminho (casa fechada): vai reto e quebra o que estiver na frente
                this.getMoveControl().moveTo(p.getX(), p.getY(), p.getZ(), speed);
            }
        }
    }

    /** Se tiver vidro ou porta na frente indo em direcao ao player, comeca a quebrar. */
    private void breakThrough(ServerWorld world, PlayerEntity p, int minAge) {
        if (breaking != null || this.age < minAge || this.age % 5 != 0) return;
        if (!this.horizontalCollision && !this.getNavigation().isIdle()) {
            // mesmo andando, checa se a porta/vidro esta bem na frente
            BlockPos front = findObstacle(world, p, 0.9);
            if (front == null) return;
            breaking = front;
            breakProgress = 0;
            return;
        }
        BlockPos obstacle = findObstacle(world, p, 1.4);
        if (obstacle != null) {
            breaking = obstacle;
            breakProgress = 0;
        }
    }

    private BlockPos findObstacle(ServerWorld world, PlayerEntity p, double reach) {
        Vec3d dir = new Vec3d(p.getX() - getX(), 0, p.getZ() - getZ());
        if (dir.lengthSquared() < 1.0E-4) return null;
        dir = dir.normalize();
        for (double step = 0.6; step <= reach + 0.01; step += 0.4) {
            BlockPos base = BlockPos.ofFloored(getX() + dir.x * step, getY(), getZ() + dir.z * step);
            for (int dy = 0; dy < 3; dy++) {
                BlockPos q = base.up(dy);
                if (Breakables.isBreakable(world, q, world.getBlockState(q))) return q;
            }
        }
        return null;
    }

    // -------------------------------------------------------------- quebrar

    private static boolean griefing(ServerWorld world) {
        return world.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING);
    }

    /** @return true quando terminou (quebrou ou o bloco sumiu). */
    private boolean tickBreak(ServerWorld world, BlockPos pos, int total) {
        BlockState state = world.getBlockState(pos);
        boolean door = Breakables.isDoor(state);
        if (!Breakables.isBreakable(world, pos, state)) {
            world.setBlockBreakingInfo(this.getId(), pos, -1);
            breaking = null;
            return true;
        }
        this.getLookControl().lookAt(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
        breakProgress++;

        if (breakProgress % (door ? 20 : 8) == 1) {
            this.swingHand(Hand.MAIN_HAND);
            if (door) {
                boolean iron = state.getBlock() instanceof DoorBlock && !state.isIn(net.minecraft.registry.tag.BlockTags.WOODEN_DOORS);
                world.syncWorldEvent(iron ? WorldEvents.ZOMBIE_ATTACKS_IRON_DOOR : WorldEvents.ZOMBIE_ATTACKS_WOODEN_DOOR, pos, 0);
            } else {
                world.playSound(null, pos, SoundEvents.BLOCK_GLASS_HIT, SoundCategory.HOSTILE, 1.5f, 0.7f);
            }
        }

        if (!griefing(world)) {
            // mobGriefing desligado: so assusta, nao quebra
            if (breakProgress >= total) {
                breaking = null;
                return true;
            }
            return false;
        }

        int stage = Math.min(9, (int) (breakProgress / (float) total * 10f));
        world.setBlockBreakingInfo(this.getId(), pos, stage);

        if (breakProgress >= total) {
            world.setBlockBreakingInfo(this.getId(), pos, -1);
            world.breakBlock(pos, false);
            if (door) {
                world.syncWorldEvent(WorldEvents.ZOMBIE_BREAKS_WOODEN_DOOR, pos, 0);
            } else {
                world.playSound(null, pos, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.HOSTILE, 2.0f, 0.6f);
                Net.crack(world, pos);
            }
            breaking = null;
            return true;
        }
        return false;
    }

    // --------------------------------------------------------------- ataque

    private void attack(ServerWorld world, PlayerEntity p, boolean forceScare) {
        if (attackCooldown > 0) return;
        attackCooldown = 20;
        this.swingHand(Hand.MAIN_HAND);
        boolean hit = this.tryAttack(p);
        if ((hit || forceScare) && p instanceof ServerPlayerEntity sp) {
            Net.jumpscare(sp, kind);
        }
    }

    private boolean isWatchedBy(PlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f).normalize();
        Vec3d to = new Vec3d(getX() - p.getX(), getBodyY(0.6) - p.getEyeY(), getZ() - p.getZ());
        double len = to.length();
        if (len < 1.0E-3 || len > 96) return false;
        double dot = look.dotProduct(to.multiply(1.0 / len));
        return dot > 0.93 && p.canSee(this);
    }

    public void vanish() {
        if (this.getWorld() instanceof ServerWorld world) {
            world.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getBodyY(0.5), getZ(), 30,
                    0.3, kind.height / 3.0, 0.3, 0.02);
            world.playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                    SoundCategory.HOSTILE, 1.0f, 0.4f);
            if (breaking != null) world.setBlockBreakingInfo(this.getId(), breaking, -1);
        }
        this.discard();
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (!this.getWorld().isClient && source.getAttacker() instanceof PlayerEntity) {
            if (kind.behavior == Behavior.CHASER || getStalkerState() != S_STALK) {
                startChase();
            } else {
                scared = true;
            }
        }
        return super.damage(source, amount);
    }

    // -------------------------------------------------------------- outros

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    @Override
    public boolean shouldRender(double distance) {
        return distance < 160.0 * 160.0;
    }

    @Override
    public Box getVisibilityBoundingBox() {
        double hw = kind.height * kind.aspect / 2.0 + 0.5;
        return new Box(getX() - hw, getY() - 0.2, getZ() - hw, getX() + hw, getY() + kind.height + 0.3, getZ() + hw);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_ENDERMAN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_ENDERMAN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_ENDERMAN_DEATH;
    }

    @Override
    public float getSoundPitch() {
        return 0.45f + this.random.nextFloat() * 0.1f;
    }

    @Override
    public int getMinAmbientSoundDelay() {
        return 200;
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("Announced", announced);
        nbt.putInt("Life", life);
        nbt.putInt("SState", getStalkerState());
        nbt.putInt("Wait", waitTicks);
        if (objective != null) nbt.putLong("Objective", objective.asLong());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        announced = nbt.getBoolean("Announced");
        life = nbt.getInt("Life");
        setStalkerState(nbt.getInt("SState"));
        if (nbt.contains("Wait")) waitTicks = nbt.getInt("Wait");
        if (nbt.contains("Objective")) objective = BlockPos.fromLong(nbt.getLong("Objective"));
    }

    @Override
    public boolean isPushable() {
        return kind.behavior != Behavior.EYES;
    }
}
