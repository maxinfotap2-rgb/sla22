package com.stalkers;

import com.stalkers.entity.StalkerType;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

public final class Net {
    public static final Identifier APPEAR = new Identifier(StalkersMod.MODID, "appear");
    public static final Identifier CRACK = new Identifier(StalkersMod.MODID, "crack");
    public static final Identifier JUMPSCARE = new Identifier(StalkersMod.MODID, "jumpscare");

    private Net() {
    }

    /** "ELE ESTA POR PERTO" para quem estiver a ate 64 blocos. */
    public static void appear(ServerWorld world, Entity stalker) {
        for (ServerPlayerEntity p : world.getPlayers()) {
            if (p.squaredDistanceTo(stalker) < 64 * 64) {
                ServerPlayNetworking.send(p, APPEAR, PacketByteBufs.empty());
            }
        }
    }

    /** Tela rachando com sangue para quem estiver perto da janela quebrada. */
    public static void crack(ServerWorld world, BlockPos pos) {
        for (ServerPlayerEntity p : world.getPlayers()) {
            if (p.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) < 20 * 20) {
                ServerPlayNetworking.send(p, CRACK, PacketByteBufs.empty());
            }
        }
    }

    public static void jumpscare(ServerPlayerEntity player, StalkerType type) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeVarInt(type.ordinal());
        ServerPlayNetworking.send(player, JUMPSCARE, buf);
    }
}
