package com.stalkers.client;

import com.stalkers.entity.StalkerEntity;
import com.stalkers.entity.StalkerType;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Desenha o stalker como uma figura 2D recortada que sempre vira de frente para voce.
 */
public class StalkerRenderer extends EntityRenderer<StalkerEntity> {

    public StalkerRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.0f;
    }

    @Override
    public Identifier getTexture(StalkerEntity entity) {
        return entity.isAngryVisual() ? entity.kind.angryTexture : entity.kind.texture;
    }

    @Override
    public void render(StalkerEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        StalkerType k = entity.kind;
        float h = k.height;
        float w = h * k.aspect;

        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - this.dispatcher.camera.getYaw()));

        if (entity.isAngryVisual()) {
            // treme quando esta correndo atras de voce
            float t = entity.age + tickDelta;
            matrices.translate(Math.sin(t * 2.7) * 0.04, Math.abs(Math.sin(t * 1.3)) * 0.03, 0.0);
        }

        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(getTexture(entity)));
        int l = k.fullbright ? LightmapTextureManager.MAX_LIGHT_COORDINATE : light;
        MatrixStack.Entry entry = matrices.peek();
        Matrix4f pos = entry.getPositionMatrix();
        Matrix3f nrm = entry.getNormalMatrix();

        float x0 = -w / 2f, x1 = w / 2f;
        vertex(vc, pos, nrm, x0, 0f, 0f, 1f, l);
        vertex(vc, pos, nrm, x1, 0f, 1f, 1f, l);
        vertex(vc, pos, nrm, x1, h, 1f, 0f, l);
        vertex(vc, pos, nrm, x0, h, 0f, 0f, l);

        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    private static void vertex(VertexConsumer vc, Matrix4f pos, Matrix3f nrm, float x, float y, float u, float v, int light) {
        vc.vertex(pos, x, y, 0f)
                .color(255, 255, 255, 255)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(nrm, 0f, 1f, 0f)
                .next();
    }
}
