package com.stalkers.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.stalkers.Net;
import com.stalkers.StalkersMod;
import com.stalkers.entity.StalkerEntity;
import com.stalkers.entity.StalkerType;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.Random;

/**
 * Tudo que aparece na tela:
 * - "ELE ESTA POR PERTO" vermelho por 1 segundo quando um stalker aparece
 * - "RUN RUN RUN" vermelho com glitch no topo enquanto um stalker te persegue
 * - tela rachando com sangue quando uma janela e quebrada perto de voce
 * - jumpscare quando um stalker te pega
 */
public final class HorrorHud {
    private static final Random R = new Random();

    private static final String APPEAR_TEXT = "ELE ESTÁ POR PERTO";
    private static final String RUN_TEXT = "RUN RUN RUN";
    private static final char[] GLITCH = {'#', '%', '@', '▓', '▒', '█', '/', '\\', '!'};

    private static final Identifier[] CRACKS = {
            tex("glass_crack_1"), tex("glass_crack_2"), tex("glass_crack_3")};
    private static final Identifier[] BLOOD = {
            tex("glass_blood_1"), tex("glass_blood_2"), tex("glass_blood_3"), tex("glass_blood_4")};

    private static final int APPEAR_DURATION = 20; // 1 segundo
    private static final int CRACK_DURATION = 140;
    private static final int JUMP_DURATION = 16;

    private static int appearTicks;
    private static int crackTicks;
    private static int jumpTicks;
    private static StalkerType jumpType = StalkerType.RUN;
    private static final float[][] crackSpots = new float[3][3];
    private static boolean wasChased;

    private HorrorHud() {
    }

    private static Identifier tex(String name) {
        return new Identifier(StalkersMod.MODID, "textures/gui/" + name + ".png");
    }

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(Net.APPEAR, (client, handler, buf, sender) ->
                client.execute(() -> {
                    appearTicks = APPEAR_DURATION;
                    play(SoundEvents.ENTITY_ENDERMAN_STARE, 0.5f, 0.7f);
                }));

        ClientPlayNetworking.registerGlobalReceiver(Net.CRACK, (client, handler, buf, sender) ->
                client.execute(() -> {
                    crackTicks = CRACK_DURATION;
                    for (float[] c : crackSpots) {
                        c[0] = 0.15f + R.nextFloat() * 0.7f; // x
                        c[1] = 0.15f + R.nextFloat() * 0.7f; // y
                        c[2] = 0.45f + R.nextFloat() * 0.5f; // tamanho
                    }
                    play(SoundEvents.BLOCK_GLASS_BREAK, 0.6f, 1.0f);
                }));

        ClientPlayNetworking.registerGlobalReceiver(Net.JUMPSCARE, (client, handler, buf, sender) -> {
            int ord = buf.readVarInt();
            client.execute(() -> {
                StalkerType[] all = StalkerType.values();
                jumpType = ord >= 0 && ord < all.length ? all[ord] : StalkerType.RUN;
                jumpTicks = JUMP_DURATION;
                play(SoundEvents.ENTITY_ENDERMAN_SCREAM, 0.6f, 1.0f);
                play(SoundEvents.ENTITY_GHAST_HURT, 0.5f, 1.0f);
            });
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (appearTicks > 0) appearTicks--;
            if (crackTicks > 0) crackTicks--;
            if (jumpTicks > 0) jumpTicks--;
            boolean chased = isBeingChased(client);
            if (chased && !wasChased) play(SoundEvents.ENTITY_WARDEN_HEARTBEAT, 0.6f, 1.0f);
            if (chased && client.world != null && client.world.getTime() % 12 == 0) {
                play(SoundEvents.ENTITY_WARDEN_HEARTBEAT, 0.8f, 0.6f);
            }
            wasChased = chased;
        });

        HudRenderCallback.EVENT.register(HorrorHud::render);
    }

    private static void play(SoundEvent sound, float pitch, float volume) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(sound, pitch, volume));
    }

    private static boolean isBeingChased(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) return false;
        int me = mc.player.getId();
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof StalkerEntity s && s.getStalkerState() == StalkerEntity.S_CHASE && s.getTargetId() == me) {
                return true;
            }
        }
        return false;
    }

    private static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        long time = mc.world.getTime();

        // ---------------------------------------------------- vidro rachado
        if (crackTicks > 0) {
            int elapsed = CRACK_DURATION - crackTicks;
            float alpha = crackTicks < 40 ? crackTicks / 40f : 1f;
            RenderSystem.enableBlend();
            RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
            for (int i = 0; i < crackSpots.length; i++) {
                if (elapsed < i * 3) continue;
                float[] c = crackSpots[i];
                int size = (int) (sh * c[2]);
                int x = (int) (c[0] * sw) - size / 2;
                int y = (int) (c[1] * sh) - size / 2;
                int stage = Math.min(2, (elapsed - i * 3) / 2);
                ctx.drawTexture(CRACKS[stage], x, y, size, size, 0f, 0f, 128, 128, 128, 128);
                if (elapsed > 10 + i * 3) {
                    int b = Math.min(3, (elapsed - 10 - i * 3) / 4);
                    ctx.drawTexture(BLOOD[b], x, y, size, size, 0f, 0f, 128, 128, 128, 128);
                }
            }
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
            RenderSystem.disableBlend();
        }

        // ------------------------------------------------- RUN RUN RUN
        if (isBeingChased(mc)) {
            int pulse = (int) (40 + 30 * Math.sin(time * 0.6 + tickDelta));
            // bordas vermelhas pulsando
            int edge = Math.max(8, sh / 10);
            int col = (pulse << 24) | 0x880000;
            ctx.fill(0, 0, sw, edge, col);
            ctx.fill(0, sh - edge, sw, sh, col);
            ctx.fill(0, 0, edge, sh, col);
            ctx.fill(sw - edge, 0, sw, sh, col);

            String txt = glitch(RUN_TEXT);
            float scale = 3.5f;
            int jx = R.nextInt(5) - 2;
            int jy = R.nextInt(3) - 1;
            if (R.nextInt(10) == 0) jx += R.nextInt(15) - 7; // salto de glitch
            drawScaled(ctx, tr, txt, sw / 2f + jx - 2, 10 + jy, scale, 0xA000FFFF);  // fantasma ciano
            drawScaled(ctx, tr, txt, sw / 2f + jx + 2, 10 + jy + 1, scale, 0xC0550000); // sombra vermelha escura
            drawScaled(ctx, tr, txt, sw / 2f + jx, 10 + jy, scale, 0xFFFF0000);       // principal
            if (R.nextInt(4) == 0) {
                // faixa "cortada" deslocada
                int sliceY = 10 + R.nextInt(25);
                ctx.fill(sw / 2 - 120 + R.nextInt(30), sliceY, sw / 2 + 120 - R.nextInt(30), sliceY + 2, 0x90FF0000);
            }
        }

        // ------------------------------------------- ELE ESTA POR PERTO
        if (appearTicks > 0) {
            float a = appearTicks > 5 ? 1f : appearTicks / 5f;
            int alpha = Math.max(8, (int) (a * 255));
            if (appearTicks > APPEAR_DURATION - 4) {
                ctx.fill(0, 0, sw, sh, 0x40AA0000); // flash vermelho rapido
            }
            int jx = R.nextInt(3) - 1;
            drawScaled(ctx, tr, APPEAR_TEXT, sw / 2f + jx, sh / 2f - 30, 2.6f, (alpha << 24) | 0xFF0000);
        }

        // ----------------------------------------------------- jumpscare
        if (jumpTicks > 0) {
            ctx.fill(0, 0, sw, sh, 0xFF000000);
            int h = (int) (sh * 1.15f);
            int w = (int) (h * jumpType.aspect);
            if (w > sw * 1.3f) {
                w = (int) (sw * 1.3f);
                h = (int) (w / jumpType.aspect);
            }
            int shake = 10;
            int x = (sw - w) / 2 + R.nextInt(shake * 2) - shake;
            int y = (sh - h) / 2 + R.nextInt(shake * 2) - shake + (int) (sh * 0.08f);
            RenderSystem.enableBlend();
            ctx.drawTexture(jumpType.angryTexture, x, y, w, h, 0f, 0f, 256, 256, 256, 256);
            RenderSystem.disableBlend();
            ctx.fill(0, 0, sw, sh, ((jumpTicks % 2 == 0) ? 0x30 : 0x10) << 24 | 0xFF0000);
        }
    }

    private static String glitch(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (char ch : s.toCharArray()) {
            if (ch != ' ' && R.nextInt(100) < 7) b.append(GLITCH[R.nextInt(GLITCH.length)]);
            else b.append(ch);
        }
        return b.toString();
    }

    private static void drawScaled(DrawContext ctx, TextRenderer tr, String text, float cx, float y, float scale, int color) {
        ctx.getMatrices().push();
        ctx.getMatrices().translate(cx, y, 0f);
        ctx.getMatrices().scale(scale, scale, 1f);
        ctx.drawText(tr, text, -tr.getWidth(text) / 2, 0, color, true);
        ctx.getMatrices().pop();
    }
}
