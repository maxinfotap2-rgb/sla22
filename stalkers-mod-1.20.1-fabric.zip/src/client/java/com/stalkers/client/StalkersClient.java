package com.stalkers.client;

import com.stalkers.entity.StalkerType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class StalkersClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        for (StalkerType k : StalkerType.values()) {
            EntityRendererRegistry.register(k.entityType(), StalkerRenderer::new);
        }
        HorrorHud.init();
    }
}
