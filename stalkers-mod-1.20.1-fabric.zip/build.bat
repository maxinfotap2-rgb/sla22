@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Stalkers - gerando o .jar
echo.
echo  ==============================================
echo    STALKERS - gerando o mod (.jar)
echo  ==============================================
echo.

set JM=0
for /f "tokens=2" %%v in ('javac -version 2^>^&1') do set JV=%%v
if defined JV for /f "tokens=1 delims=." %%m in ("%JV%") do set JM=%%m
if %JM% GEQ 21 goto build

echo  Precisa do Java 21 (JDK) para gerar o mod.
echo.
where winget >nul 2>nul
if errorlevel 1 goto manual
echo  Vou instalar o Java 21 (Eclipse Temurin) pelo winget...
winget install -e --id EclipseAdoptium.Temurin.21.JDK --accept-package-agreements --accept-source-agreements
echo.
echo  Pronto. FECHE esta janela e de dois cliques no build.bat de novo.
pause
exit /b

:manual
echo  Baixe e instale o "JDK 21" em: https://adoptium.net/temurin/releases/?version=21
echo  Depois feche esta janela e de dois cliques no build.bat de novo.
pause
exit /b

:build
echo  Java %JV% encontrado. Gerando... (a primeira vez demora uns 5-10 minutos,
echo  porque baixa o Minecraft e o Fabric. Das proximas e rapido.)
echo.
call gradlew.bat build --no-daemon
if errorlevel 1 goto fail

copy /y "build\libs\stalkers-1.0.0.jar" "stalkers-1.0.0.jar" >nul
echo.
echo  ==============================================
echo    PRONTO! O arquivo stalkers-1.0.0.jar esta
echo    nesta pasta. Coloque ele na pasta "mods"
echo    do seu Minecraft 1.20.1 Fabric junto com
echo    o Fabric API.
echo  ==============================================
explorer /select,"%~dp0stalkers-1.0.0.jar"
pause
exit /b

:fail
echo.
echo  DEU ERRO. Tire um print (ou copie o texto acima)
echo  e mande para o Claude que ele corrige.
pause
